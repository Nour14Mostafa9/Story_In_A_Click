import 'package:first/Login.dart';
import 'package:flutter/material.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final email=TextEditingController();
  final name=TextEditingController();
  final password=TextEditingController();
  var formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
            image: DecorationImage(
                image:AssetImage("assets/splash1.jpg"),
                fit: BoxFit.cover
            )
        ),
        child: Center(
          child: Form(
            key:formkey ,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                        height: 30
                    ),
                    Center(
                      child: Container(
                        width: 300,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),

                        ),
                        child:  TextFormField(
                          validator: (value){
                            if(value== null || value.isEmpty){
                              return"Please Enter Your Email";
                            }
                            return null;
                          },
                          controller: name,
                          keyboardType: TextInputType.name,
                          decoration:  InputDecoration(

                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0)
                            ),
                            hintText: 'Enter Your Name',

                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    // const Text(" Email",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold)),
                    const SizedBox(
                        height: 10
                    ),
                    Center(
                      child: Container(
                        width: 300,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),

                        ),
                        child:  TextFormField(
                          validator: (value){
                            if(value== null || value.isEmpty && value.contains('@')){
                              return"Please Enter Your Email";
                            }
                            return null;
                          },
                          controller: email,
                          keyboardType: TextInputType.emailAddress,
                          decoration:  InputDecoration(

                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0)
                            ),
                            hintText: 'Enter Your Email',

                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    // const Text(" Password",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold)),
                    const SizedBox(
                        height: 10
                    ),
                    Center(
                      child: Container(
                        width: 300,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),

                        ),
                        child:  TextFormField(
                          validator: (value){
                            if(value== null || value.isEmpty){
                              return"Please Enter Your Email";
                            }
                            return null;
                          },
                          controller: password,
                          keyboardType: TextInputType.visiblePassword,
                          decoration:  InputDecoration(

                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0)
                            ),
                            hintText: 'Enter Your Password',

                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    const SizedBox(
                        height: 40
                    ),
                    Center(
                      child: Container(
                        width: 200,
                        child: ElevatedButton(
                            style:ElevatedButton.styleFrom(
                              elevation: 10,
                              backgroundColor:  Colors.green.shade200 ,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30.0),

                              ),
                            ),
                            onPressed: (){

                                if(formkey.currentState!.validate()) {
                                  // Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_)=> const Navigation()));
                                }




                            },
                            child: const Text("SIGN UP", style: TextStyle(color: Colors.white, fontSize: 20),)),
                      ),
                    ),
                    const SizedBox(
                        height: 20
                    ),
                     Center(
                      child:  Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text("already have an account ?",style: TextStyle(color: Colors.white ,fontSize:20),),
                          const SizedBox(
                              width: 20
                          ),
                          InkWell(
                             onTap: (){
                               Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_)=>const Login()));
                             },
                             child: const Text("Log In",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),),)
                        ],
                      ),
                    )

                  ],
                ),
              ),
            ),
          ),
        ),
      ),

    );

  }


}


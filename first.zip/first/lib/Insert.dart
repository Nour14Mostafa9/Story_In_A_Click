import 'package:first/SqfLiteHelper/Sqflite.dart';
import 'package:flutter/material.dart';
import 'package:first/Home.dart';

class Insert extends StatefulWidget {
  const Insert({super.key});

  @override
  State<Insert> createState() => _CreationState();
}

class _CreationState extends State<Insert> {


  Sqflite db = Sqflite();

  @override
  final animal=TextEditingController();
  final url=TextEditingController();
  final place=TextEditingController();
  var formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        child: Center(
          child: Form(
            key:formkey ,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text("Insert Animal/Place",style: TextStyle(color: Colors.green.shade200,fontSize: 30,fontWeight: FontWeight.bold),),
                    ),
                    const SizedBox(
                        height: 100
                    ),
                    Center(
                      child: Container(
                        width: 300,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),

                        ),
                        child:  TextFormField(
                          validator: (value){
                            if(value== null || value.isEmpty){
                              return"Please Enter animal";
                            }
                            return null;
                          },
                          controller: animal,
                          //controller: place,
                          keyboardType: TextInputType.name,
                          decoration:  InputDecoration(
                            labelText: "animal",
                           // labelText: "place",
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0)
                            ),

                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    const SizedBox(
                        height: 10
                    ),
                    Center(
                      child: Container(
                        width: 300,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),

                        ),
                        child:  TextFormField(
                          validator: (value){
                            if(value== null || value.isEmpty){
                              return"Please Enter url";
                            }
                            return null;
                          },
                          controller: url,
                          keyboardType: TextInputType.text,
                          decoration:  InputDecoration(
                            labelText: "url",
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0)
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    const SizedBox(
                        height: 70
                    ),
                    Center(
                      child: Container(
                        width: 200,
                        child: ElevatedButton(
                            style:ElevatedButton.styleFrom(
                              elevation: 10,
                              backgroundColor:  Colors.green.shade200 ,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30.0),

                              ),
                            ),
                            onPressed: () async{
                              if(formkey.currentState!.validate()){
                                int response = await db.insertInitialAnimalData({
                                  "name":"${animal.text}",
                                  "url":"https://drive.google.com/uc?export=view&id=${url.text}"
                                });

                                print("$response");
                                print("https://drive.google.com/uc?export=view&id=${url.text}");
                                /*
                                int response = await db.insertInitialPlaceData({
                                  "place":"${place.text}",
                                  "url":"https://drive.google.com/uc?export=view&id=${url.text}"
                                });

                                print("$response");
                                print("https://drive.google.com/uc?export=view&id=${url.text}");

                                */

                              }
                            },
                            child: const Text("Insert", style: TextStyle(color: Colors.white, fontSize: 20),)),
                      ),
                    ),
                    const SizedBox(
                        height: 20
                    ),

                  ],
                ),
              ),
            ),
          ),
        ),
      ),

    );
  }
}

import 'package:first/SqfLiteHelper/Sqflite.dart';
import 'package:flutter/material.dart';
import 'package:first/Home.dart';

class Creation extends StatefulWidget {
  const Creation({super.key});

  @override
  State<Creation> createState() => _CreationState();
}

class _CreationState extends State<Creation> {

  Sqflite db = Sqflite();


  final Fchar=TextEditingController();
  final Schar=TextEditingController();
  final place=TextEditingController();
  var formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        child: Center(
          child: Form(
            key:formkey ,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text("Create Scene",style: TextStyle(color: Colors.green.shade200,fontSize: 30,fontWeight: FontWeight.bold),),
                    ),
                    const SizedBox(
                        height: 100
                    ),
                    Center(
                      child: Container(
                        width: 300,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),

                        ),
                        child:  TextFormField(
                          validator: (value){
                            if(value== null || value.isEmpty){
                              return"Please Enter animal";
                            }
                            return null;
                          },
                          controller: Schar,
                          keyboardType: TextInputType.name,
                          decoration:  InputDecoration(
                            labelText: "Character 1",
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0)
                            ),

                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    const SizedBox(
                        height: 10
                    ),
                    Center(
                      child: Container(
                        width: 300,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),

                        ),
                        child:  TextFormField(
                          validator: (value){
                            if(value== null || value.isEmpty){
                              return"Please Enter animal name";
                            }
                            return null;
                          },
                          controller: Fchar,
                          keyboardType: TextInputType.emailAddress,
                          decoration:  InputDecoration(
                            labelText: "Character 2",
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0)
                            ),


                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    // const Text(" Password",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold)),
                    const SizedBox(
                        height: 10
                    ),
                    Center(
                      child: Container(
                        width: 300,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),

                        ),
                        child:  TextFormField(
                          validator: (value){
                            if(value== null || value.isEmpty){
                              return"Please Enter place";
                            }
                            return null;
                          },
                          controller: place,
                          keyboardType: TextInputType.visiblePassword,
                          decoration:  InputDecoration(

                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0)
                            ),
                            labelText: 'Place ',

                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                        height: 70
                    ),
                    Center(
                      child: Container(
                        width: 200,
                        child: ElevatedButton(
                            style:ElevatedButton.styleFrom(
                              elevation: 10,
                              backgroundColor:  Colors.green.shade200 ,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30.0),

                              ),
                            ),
                            onPressed: (){

                              if(formkey.currentState!.validate()){
                              //  sq.deleteDB();
                                 Navigator.of(context).push(
                                    MaterialPageRoute(builder: (_)=> Home(
                                     place: place.text, Fchar: Fchar.text, Schar: Schar.text,
                                    )));
                              }

                            },
                            child: const Text("Create Scene ", style: TextStyle(color: Colors.white, fontSize: 20),)),
                      ),
                    ),
                    const SizedBox(
                        height: 20
                    ),

                  ],
                ),
              ),
            ),
          ),
        ),
      ),

    );
  }
}

import 'package:first/Home.dart';
import 'package:first/Insert.dart';
import 'package:first/Login.dart';
import 'package:first/SignUp.dart';
import 'package:first/Splash.dart';
import 'package:first/SqfLiteHelper/Sqflite.dart';
import 'package:first/StoryCreation.dart';
import 'package:flutter/material.dart';

void main() async {

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
      ),
      home: const Creation(),
    );
  }
}



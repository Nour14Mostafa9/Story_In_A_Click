import 'package:first/SqfLiteHelper/Sqflite.dart';
import 'package:first/StoryCreation.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {

  String place,Fchar,Schar;
   Home({super.key,required this.place,required this.Fchar,required this.Schar});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {

   Sqflite sqfLite = Sqflite();
   String? Fanimal ;
   String? Sanimal ;
   String? place ;
   List animal= [];
   bool isLoading = true;


   Future<List<Map>> ReadData()async{
     List<Map> response = await sqfLite.readAnimalData();
     print(response);
     return response;
   }

  Future Retrieve()async{
     Fanimal = await sqfLite.getUrlByAnimalName(widget.Fchar);
     Sanimal = await sqfLite.getUrlByAnimalName(widget.Schar);
    // String place = await sqfLite.getUrlByAnimalName(widget.Schar);
     print("$Fanimal");
     animal.add(Fanimal);
     animal.add(Sanimal);
     if (Fanimal != null || Sanimal != null) {
       print('URL for animal: $Fanimal'+ '$Sanimal');
     } else {
       print('Animal not found');
     }
     isLoading = false;
     setState(() {
     });

   }



  @override
  void initState() {
    super.initState();
    Retrieve();
    ReadData();

}

  /*_getWolfUrl() async {
    wolfUrl = await sqfLite.getUrlByAnimalId(1);


    if (wolfUrl != null) {
      print('URL for wolf: $wolfUrl');
    } else {
      print('Animal not found');
    }


    setState(() {});
  }*/



@override
  Widget build(BuildContext context) {

    return  Scaffold(
      backgroundColor: Colors.white,
        body: Container(
          width: double.infinity,
          height: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 300,
                child: Expanded(
                  child: ListView(
                    children:[
                      Stack(
                      children:[
                        Center(
                          child: Container(
                              width: double.infinity,
                              height: 300,
                              //https://drive.google.com/file/d/1q5zVk2HVX_m9QbRDg-h3Mde4p_xE55Eb/view?usp=sharing
                              child: Image.network("https://drive.google.com/uc?export=view&id=1q5zVk2HVX_m9QbRDg-h3Mde4p_xE55Eb",fit: BoxFit.cover,)),
                        ),
                        Positioned(
                          bottom: 10,
                          child: Center(
                            child: Container(
                                width: 200,
                                height: 200,
                                child: Fanimal != null
                                    ? Image.network(Fanimal!, fit: BoxFit.cover)
                                    : CircularProgressIndicator(),))
                        ),
                        Positioned(
                            bottom: 10,
                            right: 5,
                            child: Center(
                                child: Container(
                                  width: 200,
                                  height: 200,
                                  child: Sanimal != null
                                      ? Image.network(Sanimal !, fit: BoxFit.cover)
                                      : CircularProgressIndicator(),))
                        )

                      ]
                    ),]
                  ),
                ),
              ),
              const SizedBox(
                height: 50,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                      style:ElevatedButton.styleFrom(
                        elevation: 10,
                        backgroundColor:  Colors.green.shade200,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),

                        ),
                      ),
                      onPressed: (){

                          Navigator.of(context).pop();

                      },
                      child: const Text("EditScene ", style: TextStyle(color: Colors.white, fontSize: 20),)),
                  const SizedBox(width: 100,),
                  ElevatedButton(
                      style:ElevatedButton.styleFrom(
                        elevation: 10,
                        backgroundColor:  Colors.green.shade200,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),

                        ),
                      ),
                      onPressed: (){
                          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_)=>const Creation()));

                      },
                      child: const Text("Next Scene", style: TextStyle(color: Colors.white, fontSize: 20),)),
                ],
              )
            ],
          ),),

    );
  }
}

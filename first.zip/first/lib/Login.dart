
import 'package:first/Home.dart';
import 'package:first/Navigation.dart';
import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final email=TextEditingController();
  final password=TextEditingController();
  var formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image:AssetImage("assets/splash1.jpg"),
            fit: BoxFit.cover
          )
        ),
        child:Form(
          key: formkey,
          child: ListView(
            children: [
              const SizedBox(
                  height: 80
              ),
              Center(
                child: Container(
                  width: 300,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),

                  ),
                  child:   TextFormField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration:  InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0)
                      ),
                      hintText: 'Please Enter Your Email',

                    ),
                    validator: (value){
                      if(value==null || value .isEmpty  && value.contains('@')){
                        return"you must enter valid data ";
                      }
                      return null;
                    },
                  ),
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              // const Text(" Password",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold)),
              const SizedBox(
                  height: 10
              ),
              Center(
                child: Container(
                  width: 300,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),

                  ),
                  child:  TextFormField(
                    validator: (value){
                      if(value == null || value.isEmpty){
                        return"Please Enter Your Password";
                      }
                      return null;
                    },
                    controller: password,
                    keyboardType: TextInputType.visiblePassword,
                    decoration:  InputDecoration(

                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0)
                      ),
                      hintText: 'Enter Your Password',

                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 40,
              ),
              Center(
                child:  SizedBox(
                  width: 200,
                  child: ElevatedButton(
                      style:ElevatedButton.styleFrom(
                        elevation: 10,
                        backgroundColor:  Colors.green.shade200,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),

                        ),
                      ),
                      onPressed: (){
                        if(formkey.currentState!.validate()){
                          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_)=>const Navigation()));
                        }
                      },
                      child: const Text("LOG IN", style: TextStyle(color: Colors.white, fontSize: 20),)),
                ),
              )



            ],
          ),
        ),
      ),
    );
  }
}

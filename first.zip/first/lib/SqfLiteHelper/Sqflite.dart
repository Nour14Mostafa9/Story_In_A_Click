import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class Sqflite {
  static Database? _db;

  Future<Database?> get dB async {
    _db ??= await initialDB();
    return _db;

  }

  initialDB() async {
    String databasePath = await getDatabasesPath();
    String databaseName = "images.db";
    String path = join(databasePath, databaseName);
    Database? myDb = await openDatabase(path,
        version: 1, onCreate: _onCreate, onUpgrade: _onUpgrade);
    return myDb;
  }

  deleteDB() async {
    String databasePath = await getDatabasesPath();
    String databaseName = "images.db";
    String path = join(databasePath, databaseName);
    await deleteDatabase(path);
    print("d");
  }

  final animalTable = "animal";
  final placeTable = "place";
/*  final idChar = "id";
  final idPlace = "id";*/
  final animalName = "name";

  final place = "place";
  final time ="time";
  final url = "url";


  _onCreate(Database db, int version) async {
    Batch batch = db.batch();
    batch.execute('''
    CREATE TABLE "$animalTable"(
      "$animalName" TEXT NOT NULL PRIMARY KEY ,
      "$url" TEXT NOT NULL
    )
  ''');

    batch.execute('''
    CREATE TABLE "$placeTable"(
      "$place" TEXT NOT NULL PRIMARY KEY ,
      "$url" TEXT NOT NULL
    )
  ''');
    print("object");
    await batch.commit();


  }


  _onUpgrade(Database db, int oldVersion, int newVersion) async {
/*    await db.execute('''
      CREATE TABLE "new_table"(
        "id" INTEGER PRIMARY KEY AUTOINCREMENT,
        "title" TEXT NOT NULL,
        "description" TEXT NOT NULL
      )
  ''');

    await db.execute('''
    INSERT INTO "new_table" ("id","title","description")
    SELECT id,title,description FROM "note";
''');

    await db.execute('''
    DROP TABLE "new_table"
''');

    await db.execute('''
    ALTER TABLE "new_table" RENAME TO "note";
''');*/

    print("onUpgrade");

  }

  insertData(String sql) async {
    Database? myDb = await dB;
    int response = await myDb!.rawInsert(sql);
    return response;
  }

  Future<int> insertInitialAnimalData(Map<String,Object?>values) async {
    Database? myDb = await dB;
    int reponse = await myDb!.insert(animalTable,values);

/*    // Inserting the first row
    await myDb!.insert(animalTable, {
      animalName: 'wolf',
      url:
      'https://drive.google.com/uc?export=view&id=1rI0JTlP0ZlDuCVgixf0uyD2mqc0Fx-KG',
    });

    await myDb.insert(animalTable, {
      animalName: 'lion',
      url:
      'https://drive.google.com/uc?export=view&id=1rI0JTlP0ZlDuCVgixf0uyD2mqc0Fx-KG', // Replace with the actual ID
    });*/
    print('Initial animal data inserted successfully!');
    return reponse;
  }

  Future<int> insertInitialPlaceData(Map<String,Object?>values) async {
    Database? myDb = await dB;
    int reponse = await myDb!.insert(placeTable,values);

/*    // Inserting the first row
    await myDb!.insert(animalTable, {
      animalName: 'wolf',
      url:
      'https://drive.google.com/uc?export=view&id=1rI0JTlP0ZlDuCVgixf0uyD2mqc0Fx-KG',
    });

    await myDb.insert(animalTable, {
      animalName: 'lion',
      url:
      'https://drive.google.com/uc?export=view&id=1rI0JTlP0ZlDuCVgixf0uyD2mqc0Fx-KG', // Replace with the actual ID
    });*/
    print('Initial place data inserted successfully!');
    return reponse;
  }

  Future<List<Map<String, dynamic>>> readAnimalData() async {
    Database? myDb = await dB;

    List<Map<String, dynamic>> result = await myDb!.query(animalTable);

    return result;
  }

  Future<List<Map<String, dynamic>>> readPlaceData() async {
    Database? myDb = await dB;

    List<Map<String, dynamic>> result = await myDb!.query(placeTable);

    return result;
  }

  Future<String?> getUrlByAnimalId(int animalId) async {
    Database? myDb = await dB;

    // Query the "animal" table to get the URL based on the provided animalId
    List<Map<String, dynamic>> result = await myDb!.query(
      animalTable,
      columns: [url],
     // where: '$idChar = ?',
      whereArgs: [animalId],
    );

    // Check if the result is not empty and return the URL
    if (result.isNotEmpty) {
      return result.first[url];
    } else {
      return null; // Return null if the animal ID is not found
    }
  }

  Future<String?> getUrlByAnimalName(String animalName) async {
    Database? myDb = await dB;

    // Query the "animal" table to get the URL based on the provided animalName
    List<Map<String, dynamic>> result = await myDb!.query(
      animalTable,
      columns: [url],
      where: 'name = ?',
      whereArgs: [animalName],
    );

    // Check if the result is not empty and return the URL
    if (result.isNotEmpty) {
      return result.first[url];
    } else {
      return null; // Return null if the animal name is not found
    }
  }

  Future<String?> getUrlByPlaceName(String placeName) async {
    Database? myDb = await dB;

    // Query the "animal" table to get the URL based on the provided animalName
    List<Map<String, dynamic>> result = await myDb!.query(
      placeTable,
      columns: [url],
      where: 'name = ?',
      whereArgs: [placeName],
    );

    // Check if the result is not empty and return the URL
    if (result.isNotEmpty) {
      return result.first[url];
    } else {
      return null; // Return null if the animal name is not found
    }
  }





















































/*  myDelete(String table, String myWhere) async {
    Database? myDb = await dB;
    int response = await myDb!.delete(table, where: myWhere);
    return response;
  }*/
/*
  updateData(String sql) async {
    Database? myDb = await dB;
    int response = await myDb!.rawUpdate(sql);
    return response;
  }*/

/*
  deleteData(String sql) async {
    Database? myDb = await dB;
    int response = await myDb!.rawDelete(sql);
    return response;
  }

    myDelete(String table, String myWhere) async {
    Database? myDb = await dB;
    int response = await myDb!.delete(table, where: myWhere);
    return response;
  }



  */


}
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:first/Home.dart';
import 'package:flutter/material.dart';

class Navigation extends StatefulWidget {
  const Navigation({super.key});

  @override
  State<Navigation> createState() => _NavigationState();
}

class _NavigationState extends State<Navigation> {

  int selectedPage=0;
  List <Widget> pages = const[
    //Home(),

  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        bottomNavigationBar: CurvedNavigationBar(
          index:selectedPage ,
          backgroundColor:Colors.white,
          color: Colors.green.shade200,
          animationDuration:const Duration(milliseconds: 300),
          onTap: (index){
            setState(() {
              selectedPage=index;
            });
          },
          items:const[
            Icon(Icons.home),
            Icon(Icons.search),
            Icon(Icons.shopping_cart_rounded),
            Icon(Icons.wallet_rounded),
            Icon(Icons.person),
          ],

        ),
        body: pages.elementAt(selectedPage)
    );
  }
}